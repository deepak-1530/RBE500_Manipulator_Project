// generated from rosidl_generator_c/resource/idl.h.em
// with input from dynamixel_sdk_custom_interfaces:srv/GetPosition.idl
// generated code does not contain a copyright notice

#ifndef DYNAMIXEL_SDK_CUSTOM_INTERFACES__SRV__GET_POSITION_H_
#define DYNAMIXEL_SDK_CUSTOM_INTERFACES__SRV__GET_POSITION_H_

#include "dynamixel_sdk_custom_interfaces/srv/detail/get_position__struct.h"
#include "dynamixel_sdk_custom_interfaces/srv/detail/get_position__functions.h"
#include "dynamixel_sdk_custom_interfaces/srv/detail/get_position__type_support.h"

#endif  // DYNAMIXEL_SDK_CUSTOM_INTERFACES__SRV__GET_POSITION_H_

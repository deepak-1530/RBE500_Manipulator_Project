// generated from rosidl_generator_c/resource/idl.h.em
// with input from dynamixel_sdk_custom_interfaces:msg/SetPosition.idl
// generated code does not contain a copyright notice

#ifndef DYNAMIXEL_SDK_CUSTOM_INTERFACES__MSG__SET_POSITION_H_
#define DYNAMIXEL_SDK_CUSTOM_INTERFACES__MSG__SET_POSITION_H_

#include "dynamixel_sdk_custom_interfaces/msg/detail/set_position__struct.h"
#include "dynamixel_sdk_custom_interfaces/msg/detail/set_position__functions.h"
#include "dynamixel_sdk_custom_interfaces/msg/detail/set_position__type_support.h"

#endif  // DYNAMIXEL_SDK_CUSTOM_INTERFACES__MSG__SET_POSITION_H_

// generated from rosidl_generator_c/resource/idl.h.em
// with input from open_manipulator_msgs:msg/OpenManipulatorState.idl
// generated code does not contain a copyright notice

#ifndef OPEN_MANIPULATOR_MSGS__MSG__OPEN_MANIPULATOR_STATE_H_
#define OPEN_MANIPULATOR_MSGS__MSG__OPEN_MANIPULATOR_STATE_H_

#include "open_manipulator_msgs/msg/detail/open_manipulator_state__struct.h"
#include "open_manipulator_msgs/msg/detail/open_manipulator_state__functions.h"
#include "open_manipulator_msgs/msg/detail/open_manipulator_state__type_support.h"

#endif  // OPEN_MANIPULATOR_MSGS__MSG__OPEN_MANIPULATOR_STATE_H_

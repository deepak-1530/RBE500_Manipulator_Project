// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef OPEN_MANIPULATOR_MSGS__MSG__OPEN_MANIPULATOR_STATE_HPP_
#define OPEN_MANIPULATOR_MSGS__MSG__OPEN_MANIPULATOR_STATE_HPP_

#include "open_manipulator_msgs/msg/detail/open_manipulator_state__struct.hpp"
#include "open_manipulator_msgs/msg/detail/open_manipulator_state__builder.hpp"
#include "open_manipulator_msgs/msg/detail/open_manipulator_state__traits.hpp"

#endif  // OPEN_MANIPULATOR_MSGS__MSG__OPEN_MANIPULATOR_STATE_HPP_

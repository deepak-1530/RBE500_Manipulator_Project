// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef OPEN_MANIPULATOR_MSGS__MSG__KINEMATICS_POSE_HPP_
#define OPEN_MANIPULATOR_MSGS__MSG__KINEMATICS_POSE_HPP_

#include "open_manipulator_msgs/msg/detail/kinematics_pose__struct.hpp"
#include "open_manipulator_msgs/msg/detail/kinematics_pose__builder.hpp"
#include "open_manipulator_msgs/msg/detail/kinematics_pose__traits.hpp"

#endif  // OPEN_MANIPULATOR_MSGS__MSG__KINEMATICS_POSE_HPP_

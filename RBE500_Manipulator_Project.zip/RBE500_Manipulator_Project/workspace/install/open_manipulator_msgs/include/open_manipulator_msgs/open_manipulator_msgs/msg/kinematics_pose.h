// generated from rosidl_generator_c/resource/idl.h.em
// with input from open_manipulator_msgs:msg/KinematicsPose.idl
// generated code does not contain a copyright notice

#ifndef OPEN_MANIPULATOR_MSGS__MSG__KINEMATICS_POSE_H_
#define OPEN_MANIPULATOR_MSGS__MSG__KINEMATICS_POSE_H_

#include "open_manipulator_msgs/msg/detail/kinematics_pose__struct.h"
#include "open_manipulator_msgs/msg/detail/kinematics_pose__functions.h"
#include "open_manipulator_msgs/msg/detail/kinematics_pose__type_support.h"

#endif  // OPEN_MANIPULATOR_MSGS__MSG__KINEMATICS_POSE_H_

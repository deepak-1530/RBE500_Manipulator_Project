// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef OPEN_MANIPULATOR_MSGS__SRV__GET_JOINT_POSITION_HPP_
#define OPEN_MANIPULATOR_MSGS__SRV__GET_JOINT_POSITION_HPP_

#include "open_manipulator_msgs/srv/detail/get_joint_position__struct.hpp"
#include "open_manipulator_msgs/srv/detail/get_joint_position__builder.hpp"
#include "open_manipulator_msgs/srv/detail/get_joint_position__traits.hpp"

#endif  // OPEN_MANIPULATOR_MSGS__SRV__GET_JOINT_POSITION_HPP_
